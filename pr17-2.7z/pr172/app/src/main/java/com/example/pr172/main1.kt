package com.example.pr172

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class main1 : AppCompatActivity() {
    private lateinit var infoTextView: TextView
    private lateinit var changePinButton: Button
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main1)
        infoTextView = findViewById(R.id.infoTextView)
        changePinButton = findViewById(R.id.changePinButton)
        sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE)
        val savedPin = sharedPreferences.getString("pinCode", null)
        infoTextView.text = "Пин-код: $savedPin"
        changePinButton.setOnClickListener {
            sharedPreferences.edit().remove("pinCode").apply()
            startActivity(Intent(this, pin::class.java))
        }
    }
}