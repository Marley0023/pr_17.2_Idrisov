package com.example.pr172

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class pin : AppCompatActivity() {
    private lateinit var pinEditText: EditText
    private lateinit var confirmButton: Button
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pin)
        pinEditText = findViewById(R.id.pinEditText)
        confirmButton = findViewById(R.id.confirmButton)
        sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE)
        val savedPin = sharedPreferences.getString("pinCode", null)
        if (savedPin == null) {
            confirmButton.setOnClickListener {
                val enteredPin = pinEditText.text.toString()
                if (enteredPin.length == 4 && enteredPin.all { it.isDigit() }) {
                    sharedPreferences.edit().putString("pinCode", enteredPin).apply()
                    startActivity(Intent(this, main1::class.java))
                } else {
                    Toast.makeText(this, "Неверный пин-код", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            confirmButton.setOnClickListener {
                val enteredPin = pinEditText.text.toString()
                if (enteredPin.length == 4 && enteredPin.all { it.isDigit() }) {
                    if (enteredPin == savedPin) {
                        startActivity(Intent(this, main1::class.java))
                    } else {
                        Toast.makeText(this, "Неверный пин-код", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Неверный пин-код", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}