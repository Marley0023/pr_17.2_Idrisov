package com.example.pr172

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity2 : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE)
        val savedPin = sharedPreferences.getString("pinCode", null)
        if (savedPin != null) {
            startActivity(Intent(this, pin::class.java))
        } else {
            startActivity(Intent(this, pin ::class.java))
        }
        finish()
    }
}